<?php 
/* 
//ANDA YAI
**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//IDRIS SUTANTO
$chat = '@UpworkRssIdChannel3';  
/* Feed RSS da cui prendere i valori */
//upwork opencart feed

$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1304336790383915010&securityToken=a429916d6872cddddacee6c7589c3f5f5fa806ff2c3c3aa07e91a129b6021dce55caa55cf3ff1f6336f8fce7386fdf14681ca453953d69f8c6cc9b84a825ef61&userUid=1304336790383915008';
/* File in cui salvare i log */
$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 60;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
