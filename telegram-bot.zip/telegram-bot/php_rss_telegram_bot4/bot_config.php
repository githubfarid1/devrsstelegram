<?php 
/* 
//ANDA YAI
**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//MUHAMMAD YASIN    
$chat = '@UpworkRssIdChannel4';  
/* Feed RSS da cui prendere i valori */
//upwork opencart feed

$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1263044224076812289&securityToken=b3a2338daeeb08432529ca5a2470218fbc30e2c5a87f04923c7e8582699d1f1a87a1f9e4b5f6aa1bc427b7b96e6e0bec38adbdb802ff1b82456a40c9c90d30b5&topic=4958139&userUid=1263044224072617984';
/* File in cui salvare i log */
$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 60;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
