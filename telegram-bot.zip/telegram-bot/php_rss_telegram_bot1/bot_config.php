<?php 
/*
//ILHAM BINTANG

**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//Ilham Bintang
$chat = '@UpworkRssIdChannel1';  
/* Feed RSS da cui prendere i valori */
//upwork opencart feed
$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1316659492100866050&securityToken=9b1f2d1bc353b7e2581c972dba750b7551a3f85b26bff4d81c2c1cbf4a79f1f87f99b80ee92bc85bf448a18e98a8d971474286140237d0c927661cf2320cd699&topic=4957276&userUid=1316659492100866048';

/* File in cui salvare i log */
$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 60;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
