<?php 
/* 
//ANDA YAI
**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//Hanief Radin Putra  
$chat = '@UpworkRssIdChannel5';  
/* Feed RSS da cui prendere i valori */
//upwork opencart feed

$rss = 'https://www.upwork.com/ab/feed/jobs/rss?q=powerpoint++presentation&sort=recency&paging=0;10&api_params=1&securityToken=738378c23f688191786292f6d55168c585d66a6bc8db6615deb10b249cf75f74d8d831e74f1afbb8e5f39774da96cb00de67301e6993130165511b8ca4d35243&userUid=1250442019904385024&orgUid=1250442019912773633';
/* File in cui salvare i log */
echo 
$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 60;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
