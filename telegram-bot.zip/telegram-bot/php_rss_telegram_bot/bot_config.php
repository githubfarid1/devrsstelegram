<?php 
/* 
**********************************
**** Variabel API Telegram ******
**********************************
*/
/* Token API Telegram. buat di @BotFather */
/* Nama Bot : RsstelegramForUpworkBot */
/* Link : t.me/RsstelegramForUpworkBot */
$token = '1826066081:AAFQM3UG973Ufa1J22PKNs0cmIzSgBTuADU';

/* Nama channel */
$chat = '@OpencartUpwork'; 
/* RSS Feed */
//$rss = 'https://www.upwork.com/ab/feed/topics/rss?securityToken=aba9cbbfce7d30a4fcd4816297a2514c0e693b730686ebbb39e1b18645bdefb8b0884f90f4e37bd1b2d974aa4a0ba5e9b1f6f207a32fad1bcecb47651256f674&userUid=753956258459901952&orgUid=753956258464096257&topic=2339733';
$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=753956258464096257&amp;securityToken=aba9cbbfce7d30a4fcd4816297a2514c0e693b730686ebbb39e1b18645bdefb8b0884f90f4e37bd1b2d974aa4a0ba5e9b1f6f207a32fad1bcecb47651256f674&amp;topic=2339733&amp;userUid=753956258459901952';
/* File log */
$log_file = 'channel_bot.log';

/* File  PID */
$pid_file = 'bot.pid';

/* waktu sleep */
$attesa = 60;

/* Tunda publikasi berita, dalam hitungan detik. 0 untuk menonaktifkan */
$ritardo = 300;

?>
