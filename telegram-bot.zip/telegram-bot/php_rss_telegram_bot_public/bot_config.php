<?php 
/* 
**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//$chat = '@UpworkIdChannel1'; 
/* Feed RSS da cui prendere i valori */
//upwork wordpress feed

//$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=753956258464096257&securityToken=aba9cbbfce7d30a4fcd4816297a2514c0e693b730686ebbb39e1b18645bdefb8b0884f90f4e37bd1b2d974aa4a0ba5e9b1f6f207a32fad1bcecb47651256f674&topic=2340289&userUid=753956258459901952';
$datarss[] = array(
    'rss' => 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1316659492100866050&securityToken=9b1f2d1bc353b7e2581c972dba750b7551a3f85b26bff4d81c2c1cbf4a79f1f87f99b80ee92bc85bf448a18e98a8d971474286140237d0c927661cf2320cd699&topic=4957276&userUid=1316659492100866048',
    'chat' => '@UpworkRssIdChannel1'
);

$datarss[] = array(
    'rss' => 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1276999654717403137&securityToken=6dea4feaf593cc936acf4114a3be43784475b3409a381571286d46f018196b20f277f08f310cd7b77d358deb6cf58f55673cf3bbd794ee316f572e0a7c3db06d&topic=4957337&userUid=1276999654713208832',
    'chat' => '@UpworkRssIdChannel2'
);
/*$datarss[] = array(
    'rss' => 'https://www.upwork.com/ab/feed/topics/rss?orgUid=753956258464096257&securityToken=aba9cbbfce7d30a4fcd4816297a2514c0e693b730686ebbb39e1b18645bdefb8b0884f90f4e37bd1b2d974aa4a0ba5e9b1f6f207a32fad1bcecb47651256f674&topic=4957890&userUid=753956258459901952',
    'chat' => '@UpworkRssIdChannel3'
);*/

$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 120;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
