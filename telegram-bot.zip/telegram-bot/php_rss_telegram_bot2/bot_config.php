<?php 
/* 
//ANDA YAI
**********************************
**** Variabili API Telegram ******
**********************************
*/
/* Token API Telegram. Da richiere a @BotFather */ 
$token = '1295718547:AAHUK3G-G0uxpw5safc9S-jFdNqk8xlqMpU'; // nama bot : UpworkGetRssBot

/* Chat a cui spedire i messaggi */
//Ilham Bintang
$chat = '@UpworkRssIdChannel2';  
/* Feed RSS da cui prendere i valori */
//upwork opencart feed

$rss = 'https://www.upwork.com/ab/feed/topics/rss?orgUid=1276999654717403137&securityToken=6dea4feaf593cc936acf4114a3be43784475b3409a381571286d46f018196b20f277f08f310cd7b77d358deb6cf58f55673cf3bbd794ee316f572e0a7c3db06d&topic=4957337&userUid=1276999654713208832';
/* File in cui salvare i log */
$log_file = 'channel_bot.log';

/* File in cui salvare il PID */
$pid_file = 'bot.pid';

/* Attesa tra un ciclo e l'altro */
$attesa = 60;

/* Ritarda la pubblicazione delle notizie, in secondi. 0 per disattivare */
$ritardo = 300;

?>
